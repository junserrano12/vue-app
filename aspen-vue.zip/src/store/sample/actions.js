export default {
    addTypographyItem: (context, item) => {
        context.commit("ADD_TYPOGRAPHY", item);
    },

    removeTypographyItem: (context, index) => {
        context.commit("REMOVE_TYPOGRAPHY", index);
    }
};
