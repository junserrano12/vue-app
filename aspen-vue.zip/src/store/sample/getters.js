export default {
    displaySubtitle: state => {
        return state.subtitle + ' - Getters'
    }
};
