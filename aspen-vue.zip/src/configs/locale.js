const locale = [
    {
        locale          : 'en',
        directions      : 'ltr'
    }
];

export default locale;