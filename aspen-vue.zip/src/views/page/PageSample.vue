<template>
    <TemplatePage>
        <template slot="contentBody">
            <div class="section">
                <h2>MODULE ACCORDION STATIC CONTENT</h2>
                <ComponentAccordion :classes="['my-accordion-class']" :display="[2,3]" toggle="toggle-all">
                     <ComponentAccordionItem title="Title 0" slot="accordionItem">
                        <template slot="content">
                            <p>{{copy.sampleParagraphText}}</p>
                            <p>{{copy.sampleParagraphText}}</p>
                            <p>{{copy.sampleParagraphText}}</p>
                            <p>{{copy.sampleParagraphText}}</p>
                        </template>
                    </ComponentAccordionItem>
                    <ComponentAccordionItem title="Title 1" slot="accordionItem">
                        <template slot="content">
                            <p>{{copy.sampleParagraphText}}</p>
                            <p>{{copy.sampleParagraphText}}</p>
                            <p>{{copy.sampleParagraphText}}</p>
                            <p>{{copy.sampleParagraphText}}</p>
                        </template>
                    </ComponentAccordionItem>
                    <ComponentAccordionItem title="Title 2" slot="accordionItem">
                        <template slot="content">
                            <p>{{copy.sampleParagraphText}}</p>
                            <p>{{copy.sampleParagraphText}}</p>
                            <p>{{copy.sampleParagraphText}}</p>
                        </template>
                    </ComponentAccordionItem>
                    <ComponentAccordionItem title="Title 3" slot="accordionItem">
                        <template slot="content">
                            <p>{{copy.sampleParagraphText}}</p>
                            <p>{{copy.sampleParagraphText}}</p>
                            <p>{{copy.sampleParagraphText}}</p>
                        </template>
                    </ComponentAccordionItem>
                </ComponentAccordion>
            </div>

            <div class="section">
                <h2>MODULE ACCORDION DATA CONTENT</h2>
                <button @click="loadRoomRates">Load Room Rates</button>
                <ComponentAccordion :items="roomrates" :classes="['other-class', 'another-class']" display="show-first" toggle="toggle-once">
                    <template slot-scope="listProps">
                        <div class="image-container thumbnail">
                            <img :src="listProps.item.image" title="" alt="" />
                        </div>
                        <div class="room-rates-description">{{listProps.item.description}}</div>
                        <span>{{listProps.item.rate}}</span>
                        <p>{{listProps.item.title}}</p>
                    </template>
                </ComponentAccordion>
            </div>

           <div class="section">
                <h2>GRID</h2>
                <div class="container">
                    <div class="row">
                        <div class="col-xs-1"><div style="text-align:center; height:300px; background:#ccc;">1</div></div>
                        <div class="col-xs-1"><div style="text-align:center; height:300px; background:#ccc;">2</div></div>
                        <div class="col-xs-1"><div style="text-align:center; height:300px; background:#ccc;">3</div></div>
                        <div class="col-xs-1"><div style="text-align:center; height:300px; background:#ccc;">4</div></div>
                        <div class="col-xs-1"><div style="text-align:center; height:300px; background:#ccc;">5</div></div>
                        <div class="col-xs-1"><div style="text-align:center; height:300px; background:#ccc;">6</div></div>
                        <div class="col-xs-1"><div style="text-align:center; height:300px; background:#ccc;">7</div></div>
                        <div class="col-xs-1"><div style="text-align:center; height:300px; background:#ccc;">8</div></div>
                        <div class="col-xs-1"><div style="text-align:center; height:300px; background:#ccc;">9</div></div>
                        <div class="col-xs-1"><div style="text-align:center; height:300px; background:#ccc;">10</div></div>
                        <div class="col-xs-1"><div style="text-align:center; height:300px; background:#ccc;">11</div></div>
                        <div class="col-xs-1"><div style="text-align:center; height:300px; background:#ccc;">12</div></div>
                    </div>
                    <div class="row">
                        <div class="col-xs-2"><div style="text-align:center; height:300px; background:#ccc;">1</div></div>
                        <div class="col-xs-2"><div style="text-align:center; height:300px; background:#ccc;">2</div></div>
                        <div class="col-xs-2"><div style="text-align:center; height:300px; background:#ccc;">3</div></div>
                        <div class="col-xs-2"><div style="text-align:center; height:300px; background:#ccc;">4</div></div>
                        <div class="col-xs-2"><div style="text-align:center; height:300px; background:#ccc;">4</div></div>
                        <div class="col-xs-2"><div style="text-align:center; height:300px; background:#ccc;">4</div></div>
                    </div>
                    <div class="row">
                        <div class="col-xs-3"><div style="text-align:center; height:300px; background:#ccc;">1</div></div>
                        <div class="col-xs-3"><div style="text-align:center; height:300px; background:#ccc;">2</div></div>
                        <div class="col-xs-3"><div style="text-align:center; height:300px; background:#ccc;">3</div></div>
                        <div class="col-xs-3"><div style="text-align:center; height:300px; background:#ccc;">4</div></div>
                    </div>
                    <div class="row">
                        <div class="col-xs-4"><div style="text-align:center; height:300px; background:#ccc;">1</div></div>
                        <div class="col-xs-4"><div style="text-align:center; height:300px; background:#ccc;">2</div></div>
                        <div class="col-xs-4"><div style="text-align:center; height:300px; background:#ccc;">3</div></div>
                    </div>
                    <div class="row">
                        <div class="col-xs-6"><div style="text-align:center; height:300px; background:#ccc;">1</div></div>
                        <div class="col-xs-6"><div style="text-align:center; height:300px; background:#ccc;">2</div></div>
                    </div>
                </div>
            </div>

            <div class="section">
                <h2>COMPONENT LIST</h2>
                <ComponentList :items="samplatestate.typographylist">
                    <template slot-scope="listProps">
                        <h3>{{listProps.item.size}}</h3>
                        <p :class="listProps.item.size">{{copy.sampleParagraphText}}</p>
                        <button @click="removeTypography(listProps.index)">Remove</button>
                        <hr>
                    </template>
                </ComponentList>
                <h3>mutation</h3>
                <form @submit.prevent="addTypography">
                   <input class="link-input" type="text" placeholder="Add a Typography Item" v-model="newTypographyItem" />
                </form>
            </div>

            <div class="section">
                <h2>COMPONENT CONTENT</h2>
                <ComponentContent prefix="my-component" title="MUTATION" tag="button">
                    <template slot="content">
                        <p>{{copy.sampleParagraphText}}</p>
                    </template>
                </ComponentContent>
                <ComponentContent prefix="my-component">
                    <template slot="content">
                        <p>{{copy.sampleParagraphText}}</p>
                    </template>
                </ComponentContent>
            </div>

            <div class="section">
                <h2>VUEX</h2>
                <h3>state</h3>
                <p>{{ samplatestate.subtitle }}</p>
                <h3>getters</h3>
                <p>{{ displaySubtitle }}</p>
            </div>

        </template>
    </TemplatePage>
</template>

<script>
/*dep*/
import axios from "axios";

/*Component*/
import ComponentList from "@/components/ComponentList.vue"
import ComponentContent from "@/components/ComponentContent.vue"
import ComponentAccordion from "@/components/ComponentAccordion.vue"
import ComponentAccordionItem from "@/components/ComponentAccordionItem.vue"

export default {
    name: "PageSample",

    components: {
        ComponentList,
        ComponentContent,
        ComponentAccordion,
        ComponentAccordionItem
    },

    computed: {
        axiosdata: function() {
            return this.$store.state.axiosdata;
        },

        samplatestate: function() {
            return this.$store.state.sample;
        },

        storedata: function() {
            return this.$store.state.storedata;
        },

        displaySubtitle: function() {
            return this.$store.getters['sample/displaySubtitle'];
        }
    },

    methods: {
        addTypography: function() {
            this.$store.dispatch("sample/addTypographyItem", this.newTypographyItem);
            this.newTypographyItem = "";
        },

        removeTypography: function(index) {
            this.$store.dispatch("sample/removeTypographyItem", index);
        },

        loadRoomRates: function() {
            axios('/api/roomrates.json').then((response) => {
                this.roomrates = response.data;
            });
        }
    },

    data() {
        return {
            newTypographyItem : "",
            roomrates: [],
            copy: { sampleParagraphText: "The club’s mission is best served by building awareness (internally, as well as with our partner member hotel team) about how to foster a community of healthier humans, so we bring the best possible energy to the work we do." }
        }
    }
}
</script>

<style lang="scss" src="@/assets/sass/page/sample.scss"></style>