<template>
    <TemplatePage>
        <template slot="contentBody">
            <p>Sorry!</p>
        </template>
    </TemplatePage>
</template>

<script>
export default {
    name: "PageNotFound"
}
</script>
