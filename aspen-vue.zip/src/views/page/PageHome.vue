<template>
    <TemplatePage>
        <template slot="contentBody">
        </template>
    </TemplatePage>
</template>

<script>
export default {
    name : "PageHome"
}
</script>