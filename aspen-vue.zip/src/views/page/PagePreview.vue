<template>
    <TemplatePage>
        <template slot="contentBody">
            PREVIEW PAGE
        </template>
    </TemplatePage>
</template>

<script>
export default {
    name : "PagePreview"
}
</script>