export default {

    methods: {
    }

};